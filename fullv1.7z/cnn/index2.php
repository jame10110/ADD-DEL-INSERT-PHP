<p></p>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<?php

include "database.php";	

//$homepage = file_get_contents('https://leads.nipa.co.th/linetv/todays');
//echo $homepage;

?>

<!--
<script>

	for (let i = 0; i < 3e1; i++){ 
		//console.log(i);
		jQuery('p').append(i);
	}

</script>
-->
<!-- 
<script>
	const number = [1,2,3];
	//const newNumber = number.concat([4,5,6]);  //  Join array
	//const newArr = number.slice();  // Clone array

	//const newNumber = [...number,4,5,6];  //  Join array short
	const newArr = [...number];  // Clone array short
	jQuery('p').append(newArr);
</script> 
-->


<?php


?>